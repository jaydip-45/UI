var express=require('express');
var router=express.Router();
var Movie=require('./Models.Movie')


//fetching data through get


router.get('/movies',async(res,res)=>{
    const iMovie=await Movie.find();
    res.send(iMovie);
})
module.exports=router;