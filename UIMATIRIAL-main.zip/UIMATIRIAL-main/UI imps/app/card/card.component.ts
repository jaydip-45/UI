import { Component, OnInit } from '@angular/core';
import { CarsService } from '../service/cars.service';


@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {

   cardss:number=1
  a=[
    {Enrolloment:'21SOECA21045',Name:'Name:- vishal',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21044',Name:'Name:- sachin',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21005',Name:'Name:- ketan',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21006',Name:'Name:- Rahul',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21007',Name:'Name:- Harshil',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21008',Name:'Name:- viraj',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21009',Name:'Name:- kanu',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21044',Name:'Name:- Manu',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21045',Name:'Name:- jay',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21045',Name:'Name:- babu',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21045',Name:'Name:- bhikho',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21045',Name:'Name:- jaydeep',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21045',Name:'Name:- sachin',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21045',Name:'Name:- sachin',photo:"../assets/images/abc.png"},
    {Enrolloment:'21SOECA21045',Name:'Name:- sachin',photo:"../assets/images/abc.png"}
  ]
  
  constructor(private pagesss:CarsService) { }

  ngOnInit(): void {
    
  }

}
