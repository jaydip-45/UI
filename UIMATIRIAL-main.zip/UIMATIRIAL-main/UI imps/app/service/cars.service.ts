import { Injectable } from '@angular/core';
import { NgxPaginationModule } from 'ngx-pagination';

@Injectable({
  providedIn: 'root'
})
export class CarsService {

  constructor(private cards:NgxPaginationModule) { }
}
